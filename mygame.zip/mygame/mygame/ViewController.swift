//
//  ViewController.swift
//  mygame
//
//  Created by 이수환 on 2023/02/13.
//

import UIKit

class Meat {
    var temper : Int = 0
    var state : Int = 0
    var isFired = false
    
    func gettingHot() {
        temper = temper + 1
    }
}

class Order {
    var state2 : Int = 0
    var state3 : Int = 0
    var state4 : Int = 0
    
    public func meatIsReady(_ meat : Meat) -> Int {
        switch meat.state {
        case 2 :
            state2 = state2 - 1
            if (state2 < 0) {
                state2 = 0
            }
            return state2
        case 3 :
            state3 = state3 - 1
            if (state3 < 0) {
                state3 = 0
            }
            return state3
        case 4 :
            state4 = state4 - 1
            if (state4 < 0) {
                state4 = 0
            }
            return state4
        default: return 0
        }
    }
}

enum meatImage : String {
    case 고기1 = "고기1"
    case 고기2 = "고기2"
    case 고기3 = "고기3"
    case 고기4 = "고기4"
    case 고기5 = "고기5"
}

enum WhichButton {
    case rotateOn
    case dish1On
    case dish2On
}

class ViewController: UIViewController {
    var timeLimit = 181
    var score : Int = 0
    var meats : [Meat] = []
    var imageViews : [UIImageView] = []
    var order1 = Order()
    var order2 = Order()
    var orderLabel1 : [UILabel] = []
    var orderLabel2 : [UILabel] = []
    
    var whichButton : WhichButton?
    
    @IBOutlet weak var order1time: UILabel!
    @IBOutlet weak var order1state2: UILabel!
    @IBOutlet weak var order1state3: UILabel!
    @IBOutlet weak var order1state4: UILabel!
    
    @IBOutlet weak var order2time: UILabel!
    @IBOutlet weak var order2state2: UILabel!
    @IBOutlet weak var order2state3: UILabel!
    @IBOutlet weak var order2state4: UILabel!
    
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var scoreboard: UILabel!
    
    @IBOutlet weak var orderView1: UIView!
    @IBOutlet weak var orderView2: UIView!
    
    @IBOutlet weak var imageView1: UIImageView!
    @IBOutlet weak var imageView2: UIImageView!
    @IBOutlet weak var imageView3: UIImageView!
    @IBOutlet weak var imageView4: UIImageView!
    @IBOutlet weak var imageView5: UIImageView!
    @IBOutlet weak var imageView6: UIImageView!
    @IBOutlet weak var imageView7: UIImageView!
    @IBOutlet weak var imageView8: UIImageView!
    
    @IBOutlet weak var getMeatButton: UIButton!
    @IBOutlet weak var rotateMeatButton: UIButton!
    @IBOutlet weak var dish1Button: UIButton!
    @IBOutlet weak var dish2Button: UIButton!
    
    @IBAction func getMeat(_ sender: Any) {
        var i = 0
        while i < 8 {
            if meats[i].state == 0 {
                imageViews[i].image = UIImage(named: meatImage.고기1.rawValue)
                dispatchFunction(meats[i], imageViews[i])
                break;
            }
            else {
                i = i + 1
            }
        }
    }
    
    @IBAction func rotateMeat(_ sender: Any) {
        whichButton = WhichButton.rotateOn
        rotateMeatButton.backgroundColor = UIColor.yellow
        dish1Button.backgroundColor = nil
        dish2Button.backgroundColor = nil
    }
    @IBAction func dish1Meat(_ sender: Any) {
        whichButton = WhichButton.dish1On
        rotateMeatButton.backgroundColor = nil
        dish1Button.backgroundColor = UIColor.yellow
        dish2Button.backgroundColor = nil
    }
    @IBAction func dish2Meat(_ sender: Any) {
        whichButton = WhichButton.dish2On
        rotateMeatButton.backgroundColor = nil
        dish1Button.backgroundColor = nil
        dish2Button.backgroundColor = UIColor.yellow
    }
    
    @IBAction func tapRecognizer1(_ sender: Any) {
        if (meats[0].state != 0) {
            switch whichButton {
            case .rotateOn : tapFunction(meats[0],imageView1); break
            case .dish1On : toDish(meats[0], imageView1, order1, orderLabel1); break
            case .dish2On : toDish(meats[0], imageView1, order2, orderLabel2); break
            default : break }
        }
    }
    
    @IBAction func tapRecognizer2(_ sender: Any) {
        if (meats[1].state != 0) {
            switch whichButton {
            case .rotateOn : tapFunction(meats[1],imageView2); break
            case .dish1On : toDish(meats[1], imageView2, order1, orderLabel1); break
            case .dish2On : toDish(meats[1], imageView2, order2, orderLabel2); break
            default : break }
        }
    }
    @IBAction func tapRecognizer3(_ sender: Any) {
        if (meats[2].state != 0) {
            switch whichButton {
            case .rotateOn : tapFunction(meats[2],imageView3); break
            case .dish1On : toDish(meats[2], imageView3, order1, orderLabel1); break
            case .dish2On : toDish(meats[2], imageView3, order2, orderLabel2); break
            default : break }
        }
    }
    @IBAction func tapRecognizer4(_ sender: Any) {
        if (meats[3].state != 0) {
            switch whichButton {
            case .rotateOn : tapFunction(meats[3],imageView4); break
            case .dish1On : toDish(meats[3], imageView4, order1, orderLabel1); break
            case .dish2On : toDish(meats[3], imageView4, order2, orderLabel2); break
            default : break }
        }
    }
    @IBAction func tapRecognizer5(_ sender: Any) {
        if (meats[4].state != 0) {
            switch whichButton {
            case .rotateOn : tapFunction(meats[4],imageView5); break
            case .dish1On : toDish(meats[4], imageView5, order1, orderLabel1); break
            case .dish2On : toDish(meats[4], imageView5, order2, orderLabel2); break
            default : break }
        }
    }
    @IBAction func tapRecognizer6(_ sender: Any) {
        if (meats[5].state != 0) {
            switch whichButton {
            case .rotateOn : tapFunction(meats[5],imageView6); break
            case .dish1On : toDish(meats[5], imageView6, order1, orderLabel1); break
            case .dish2On : toDish(meats[5], imageView6, order2, orderLabel2); break
            default : break }
        }
    }
    @IBAction func tapRecognizer7(_ sender: Any) {
        if (meats[6].state != 0) {
            switch whichButton {
            case .rotateOn : tapFunction(meats[6],imageView7); break
            case .dish1On : toDish(meats[6], imageView7, order1, orderLabel1); break
            case .dish2On : toDish(meats[6], imageView7, order2, orderLabel2); break
            default : break }
        }
    }
    @IBAction func tapRecognizer8(_ sender: Any) {
        if (meats[7].state != 0) {
            switch whichButton {
            case .rotateOn : tapFunction(meats[7],imageView8); break
            case .dish1On : toDish(meats[7], imageView8, order1, orderLabel1); break
            case .dish2On : toDish(meats[7], imageView8, order2, orderLabel2); break
            default : break }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        print ("viewdidload")
        meats = [Meat(),Meat(),Meat(),Meat(),Meat(),Meat(),Meat(),Meat()]
        imageViews = [imageView1,imageView2,imageView3,imageView4,imageView5,imageView6,imageView7,imageView8]
        
        orderLabel1 = [order1time,order1state2,order1state3,order1state4]
        orderLabel2 = [order2time,order2state2,order2state3,order2state4]
        
        orderView1.layer.cornerRadius = 10
        orderView1.layer.borderWidth = 1.0
        orderView1.layer.borderColor = UIColor.white.cgColor
        
        orderView2.layer.cornerRadius = 10
        orderView2.layer.borderWidth = 1.0
        orderView2.layer.borderColor = UIColor.white.cgColor
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        DispatchQueue.global().async {
            let runLoop = RunLoop.current
            let timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { timer in
                self.timeLimit = (self.timeLimit) - 1
                DispatchQueue.main.async{
                    self.timeLabel.text = "남은시간 : \(self.timeLimit)초"
                }
            }
            while (self.timeLimit > 0) {
                runLoop.run(until: Date().addingTimeInterval(0.1))
            }
            timer.invalidate()
        }
        orderDispatch(order1, orderLabel1)
        orderDispatch(order2, orderLabel2)
    }
    
    func dispatchFunction  (_ meat : Meat , _ imgView : UIImageView) {
        meat.state = 1
        meat.isFired = true
        DispatchQueue.global().async {
            let runLoop = RunLoop.current
            let timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { timer in
                meat.gettingHot()
                self.changeStateByTemper(meat,imgView)
            }
            while (meat.isFired) {
                runLoop.run(until: Date().addingTimeInterval(0.1))
            }
            timer.invalidate()
        }
    }
    
    func orderDispatch(_ order : Order , _ orderLabels : [UILabel]) {
        var time = 0
        var numberOfstate2 = 0 ; var numberOfstate3 = 0 ; var numberOfstate4 = 0
        DispatchQueue.global().async {
            let runLoop = RunLoop.current
            let timer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { timer in
                time = time - 1
                DispatchQueue.main.async{
                    orderLabels[0].text = "남은 시간 : \(time)초"
                }
                if ((time == 0) || (order.state2 + order.state3 + order.state4 == 0)) {
                    if(time != 0){
                        self.score = self.score + (numberOfstate2 * 30)+(numberOfstate3 * 60)+(numberOfstate4 * 100)
                        DispatchQueue.main.async{
                            self.scoreboard.text = "현재점수 : \(self.score)점"
                        }
                    }
                    time = Int.random(in: 18...20)
                    order.state2 = Int.random(in: 0...2) ; numberOfstate2 = order.state2
                    order.state3 = Int.random(in: 0...2) ; numberOfstate3 = order.state3
                    order.state4 = Int.random(in: 0...2) ; numberOfstate4 = order.state4
                    DispatchQueue.main.async{
                        orderLabels[0].text = "남은 시간 : \(time)초"
                        orderLabels[1].text = "\(order.state2)"
                        orderLabels[2].text = "\(order.state3)"
                        orderLabels[3].text = "\(order.state4)"
                    }
                }
            }
            runLoop.run(until: Date().addingTimeInterval(180.0))
            timer.invalidate()
        }
    }
    
    func toDish(_ meat : Meat, _ meatImg : UIImageView, _ order : Order, _ orderLabels : [UILabel]) {
        // meat.state를 조사해보고 그 state에 해당하는 오더라벨의 개수를 하나 내려주세요
        let renewedOrder = order.meatIsReady(meat)
        let target = meat.state-1
        DispatchQueue.main.async {
            meatImg.image = nil
            print("target : \(target) , renewedOrder : \(renewedOrder)")
            if (target < 4 && target > 0){
                orderLabels[target].text = "\(renewedOrder)"
            }
        }
        meat.isFired = false
        meat.state = 0
        meat.temper = 0
    }
    
    func tapFunction(_ meat : Meat, _ imgView : UIImageView){
        if (meat.state != 0 ){
            DispatchQueue.main.async {
                UIView.animate(withDuration: 0.25 ) {
                    let rotate = CGAffineTransform(rotationAngle: .pi)
                    imgView.transform = rotate
                } completion: {
                    result in let rotate = CGAffineTransform(rotationAngle: .zero)
                    imgView.transform = rotate
                }
            }
            changeStateByTap(meat, imgView)
        }
    }
    
    func changeStateByTemper (_ meat : Meat , _ imgView : UIImageView) {
        switch meat.state {
        case 1 :
            if (meat.temper == 3) {
                DispatchQueue.main.async{
                    imgView.image = UIImage(named: meatImage.고기2.rawValue)
                }
                meat.state = 2
                meat.temper = 0
            }
            break;
        case 2:
            if (meat.temper == 3) {
                DispatchQueue.main.async{
                    imgView.image = UIImage(named: meatImage.고기5.rawValue)
                }
                meat.isFired = false
                meat.state = 5
                meat.temper = 0
            }
            break;
        case 3:
            if (meat.temper == 3) {
                DispatchQueue.main.async{
                    imgView.image = UIImage(named: meatImage.고기4.rawValue)
                }
                meat.state = 4
                meat.temper = 0
            }
            break;
        case 4:
            if(meat.temper == 3){
                DispatchQueue.main.async{
                    imgView.image = UIImage(named: meatImage.고기5.rawValue)
                }
                meat.isFired = false
                meat.state = 5
                meat.temper = 0
            }
            break;
        case 5:
            break;
        default:
            print ("the state is not in 1~5 in temper")
        }
    }
    
    func changeStateByTap(_ meat : Meat , _ imgView : UIImageView ) {
        switch meat.state {
            
        case 1:
            meat.temper = (meat.temper) - 1
            if meat.temper < 1 {
                meat.temper = 0
            }
            break;
        
        case 2:
            DispatchQueue.main.async{
                imgView.image = UIImage(named: meatImage.고기3.rawValue)
            }
            meat.state = 3
            meat.temper = 0
            break;
            
        case 3:
            
            meat.temper = (meat.temper) - 1
            if meat.temper < 1 {
                meat.temper = 0
            }
            break;
            
        case 4:
            meat.temper = (meat.temper) - 1
            if meat.temper < 1 {
                meat.temper = 0
            }
            break;
        
        case 5:
            DispatchQueue.main.async{
                imgView.image = nil
            }
            meat.state = 0
            meat.temper = 0
            break;
        default :
            print("the state is not in 1~5 in tap")
        }
    }
}

